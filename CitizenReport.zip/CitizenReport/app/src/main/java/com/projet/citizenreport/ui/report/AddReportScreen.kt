package com.projet.citizenreport.ui.report

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddReportScreen(
    onReportSubmitted: (title: String, desc: String, category: String, priority: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Voirie") }
    var priority by remember { mutableStateOf("Moyenne") }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Nouveau Signalement") }) }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Titre de l'incident") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )

            Button(
                onClick = {
                    if (title.isNotBlank() && description.isNotBlank()) {
                        onReportSubmitted(title, description, category, priority)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Soumettre le signalement")
            }
        }
    }
}