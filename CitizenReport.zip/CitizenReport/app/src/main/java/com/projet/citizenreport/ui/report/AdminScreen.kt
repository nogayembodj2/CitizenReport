package com.projet.citizenreport.ui.report

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.projet.citizenreport.data.local.ReportEntity

@Composable
fun AdminScreen(viewModel: ReportViewModel) {
    val reports by viewModel.reports.collectAsState(initial = emptyList())
    val recuCount by viewModel.recuCount.collectAsState()
    val enCoursCount by viewModel.enCoursCount.collectAsState()
    val resoluCount by viewModel.resoluCount.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "📊 Espace Administrateur",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Tableau de bord décisionnel (Statistiques)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            StatCard("Reçus", recuCount, Color(0xFFE8EAF6), Color(0xFF3F51B5))
            StatCard("En cours", enCoursCount, Color(0xFFFFF3E0), Color(0xFFFB8C00))
            StatCard("Résolus", resoluCount, Color(0xFFE8F5E9), Color(0xFF4CAF50))
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Gestion des Incidents",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (reports.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("Aucun incident à traiter", color = Color.Gray)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(reports, key = { it.id }) { report ->
                    AdminReportItem(
                        report = report,
                        onStatusChange = { newStatus ->
                            viewModel.changeStatus(report.id, newStatus)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, count: Int, bgColor: Color, textColor: Color) {
    Card(
        colors = CardDefaults.cardColors(containerColor = bgColor),
        modifier = Modifier.width(100.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, fontSize = 14.sp, color = Color.DarkGray)
            Text(
                count.toString(),
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
        }
    }
}

@Composable
fun AdminReportItem(
    report: ReportEntity,
    onStatusChange: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(report.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(report.description, fontSize = 13.sp, color = Color.Gray)

            // Affichage de la photo si disponible
            report.photoUri?.let { uri ->
                Spacer(modifier = Modifier.height(8.dp))
                Image(
                    painter = rememberAsyncImagePainter(uri),
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Crop
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Boutons d'action pour modifier le statut
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Statut: ${report.status}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Button(
                        onClick = { onStatusChange("En cours") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFB8C00)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("En cours", fontSize = 10.sp)
                    }

                    Button(
                        onClick = { onStatusChange("Résolu") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("Résolu", fontSize = 10.sp)
                    }
                }
            }
        }
    }
}