package com.projet.citizenreport.ui.report

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.projet.citizenreport.data.local.ReportDao
import com.projet.citizenreport.data.local.ReportEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ReportViewModel(private val dao: ReportDao) : ViewModel() {

    val reports: Flow<List<ReportEntity>> = dao.getAllReports()

    val recuCount = dao.getCountByStatus("Reçu").stateIn(viewModelScope, SharingStarted.Lazily, 0)
    val enCoursCount = dao.getCountByStatus("En cours").stateIn(viewModelScope, SharingStarted.Lazily, 0)
    val resoluCount = dao.getCountByStatus("Résolu").stateIn(viewModelScope, SharingStarted.Lazily, 0)

    fun addReport(title: String, desc: String, category: String, priority: String, photoUri: String? = null) {
        viewModelScope.launch {
            val report = ReportEntity(
                title = title,
                description = desc,
                category = category,
                priority = priority,
                photoUri = photoUri
            )
            dao.insertReport(report)
        }
    }

    fun deleteReport(report: ReportEntity) {
        viewModelScope.launch {
            dao.deleteReport(report)
        }
    }

    fun changeStatus(reportId: Int, newStatus: String) {
        viewModelScope.launch {
            dao.updateStatus(reportId, newStatus)
        }
    }
}