package com.projet.citizenreport.ui.report

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.projet.citizenreport.data.local.AppDatabase
import com.projet.citizenreport.data.local.ReportEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ReportViewModel(private val database: AppDatabase) : ViewModel() {

    val allReports: StateFlow<List<ReportEntity>> = database.reportDao().getAllReports()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun addReport(title: String, description: String, category: String, priority: String) {
        viewModelScope.launch {
            val newReport = ReportEntity(
                title = title,
                description = description,
                category = category,
                priority = priority
            )
            database.reportDao().insertReport(newReport)
        }
    }
}